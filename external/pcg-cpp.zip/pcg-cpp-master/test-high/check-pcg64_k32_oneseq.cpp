#define RNG pcg64_k32_oneseq
#define TWO_ARG_INIT 0
#define AWKWARD_128BIT_CODE 1

#include "pcg-test.cpp"

