#define RNG pcg64_c1024
#define TWO_ARG_INIT 1
#define AWKWARD_128BIT_CODE 1

#include "pcg-test-noadvance.cpp"

