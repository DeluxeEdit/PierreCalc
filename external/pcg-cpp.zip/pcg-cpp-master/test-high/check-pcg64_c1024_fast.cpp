#define RNG pcg64_c1024_fast
#define TWO_ARG_INIT 0
#define AWKWARD_128BIT_CODE 1

#include "pcg-test-noadvance.cpp"

