#define RNG pcg32_c1024
#define TWO_ARG_INIT 1

#include "pcg-test-noadvance.cpp"

