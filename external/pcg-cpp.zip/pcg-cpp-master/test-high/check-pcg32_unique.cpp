#define RNG pcg32_unique
#define TWO_ARG_INIT 0

#include "pcg-test-noadvance.cpp"

