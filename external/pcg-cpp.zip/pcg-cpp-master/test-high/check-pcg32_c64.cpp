#define RNG pcg32_c64
#define TWO_ARG_INIT 1

#include "pcg-test-noadvance.cpp"

