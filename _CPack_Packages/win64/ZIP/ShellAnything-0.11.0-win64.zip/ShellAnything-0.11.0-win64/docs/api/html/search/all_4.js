var searchData=
[
  ['patch_0',['patch',['../structsa__version__info__t.html#a21fc177e654e6ec08f79a32d3ad9c35f',1,'sa_version_info_t']]]
];
