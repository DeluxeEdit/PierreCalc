var searchData=
[
  ['name_0',['name',['../struct_x_m_l___a_t_t_r.html#ad22270108e1195d7ef9305632670cde7',1,'XML_ATTR']]]
];
