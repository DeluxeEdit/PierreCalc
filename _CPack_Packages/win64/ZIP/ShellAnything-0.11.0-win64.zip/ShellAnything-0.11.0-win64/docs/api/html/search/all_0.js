var searchData=
[
  ['group_0',['group',['../struct_x_m_l___a_t_t_r.html#a0a13ffa5f327d21d5581a99b088214b4',1,'XML_ATTR']]]
];
