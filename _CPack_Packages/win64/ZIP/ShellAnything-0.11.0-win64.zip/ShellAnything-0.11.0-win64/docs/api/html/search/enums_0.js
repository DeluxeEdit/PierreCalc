var searchData=
[
  ['sa_5faction_5fevent_5ft_0',['sa_action_event_t',['../sa__enums_8h.html#ad2f5c7d5123b003c71b964d9b1175c1a',1,'sa_enums.h']]],
  ['sa_5ferror_5ft_1',['sa_error_t',['../sa__enums_8h.html#ab80fb8f487412a4e116ca91c6e29522e',1,'sa_enums.h']]],
  ['sa_5flog_5flevel_5ft_2',['sa_log_level_t',['../sa__enums_8h.html#a7b699f91c99e46ab6a5c8ca393a58250',1,'sa_enums.h']]]
];
