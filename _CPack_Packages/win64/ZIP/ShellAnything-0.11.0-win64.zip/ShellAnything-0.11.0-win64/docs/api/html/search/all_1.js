var searchData=
[
  ['major_0',['major',['../structsa__version__info__t.html#a29a3cadf2896bb421d54b65fb88784ce',1,'sa_version_info_t']]],
  ['mandatory_1',['mandatory',['../struct_x_m_l___a_t_t_r.html#a62fe5c3b431b866a6abd562002aa56c9',1,'XML_ATTR']]],
  ['minor_2',['minor',['../structsa__version__info__t.html#aa0edb75861392e55e1d86dfeccb9a5cc',1,'sa_version_info_t']]]
];
