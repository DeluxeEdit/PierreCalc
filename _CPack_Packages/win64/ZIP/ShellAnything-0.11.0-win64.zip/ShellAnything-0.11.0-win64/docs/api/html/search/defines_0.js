var searchData=
[
  ['sa_5fattribute_5fflag_5finversed_0',['SA_ATTRIBUTE_FLAG_INVERSED',['../sa__plugin__definitions_8h.html#a21db7372a42d792db7865a698e5bf4b7',1,'sa_plugin_definitions.h']]],
  ['sa_5fattribute_5fflag_5fnone_1',['SA_ATTRIBUTE_FLAG_NONE',['../sa__plugin__definitions_8h.html#a8d9d9d009d277d86613348e114c70636',1,'sa_plugin_definitions.h']]],
  ['sa_5fplugin_5finitialize_5ffunction_5fname_2',['SA_PLUGIN_INITIALIZE_FUNCTION_NAME',['../sa__plugin__definitions_8h.html#a9a11562a20d4516971d331407e208777',1,'sa_plugin_definitions.h']]],
  ['sa_5fplugin_5fregister_5ffunction_5fname_3',['SA_PLUGIN_REGISTER_FUNCTION_NAME',['../sa__plugin__definitions_8h.html#a20c1abae7481ab272f15b9755015f6e8',1,'sa_plugin_definitions.h']]],
  ['sa_5fplugin_5fterminate_5ffunction_5fname_4',['SA_PLUGIN_TERMINATE_FUNCTION_NAME',['../sa__plugin__definitions_8h.html#a26e3694991d639d521666db45f154c1d',1,'sa_plugin_definitions.h']]]
];
