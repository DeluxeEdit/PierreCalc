var searchData=
[
  ['tmp_5fexpanded_0',['tmp_expanded',['../struct_x_m_l___a_t_t_r.html#ac96a481a9821aab5d775bdee822778af',1,'XML_ATTR']]],
  ['tmp_5fvalue_1',['tmp_value',['../struct_x_m_l___a_t_t_r.html#a76e3faa29ad9477b3d003fbb431ed2fa',1,'XML_ATTR']]]
];
